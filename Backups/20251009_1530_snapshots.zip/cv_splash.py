# cv_splash.py — lightweight splash screen for Tkinter apps
from __future__ import annotations
import time
from pathlib import Path
import tkinter as tk

try:
    from PIL import Image, ImageTk  # for JPEG/scale
    _PIL_OK = True
except Exception:
    _PIL_OK = False

# Where to look for the logo by default
def _find_logo() -> Path | None:
    here = Path(__file__).resolve()
    roots = [here.parent, here.parent.parent, here.parent.parent / "assets", here.parent / "assets"]
    names = ["logo.png", "logo.jpg", "logo.jpeg", "splash.png", "splash.jpg"]
    for r in roots:
        for n in names:
            p = (r / n)
            if p.exists():
                return p
    return None

class Splash:
    """
    Minimal, blocking-in-place splash:
      - show(): draws a borderless, topmost window with your image + title
      - close(): guarantees a minimal display time, then destroys the splash

    Usage:
        splash = Splash(image_path="assets/logo.jpg", min_show_ms=900)
        splash.show()
        # ... build your real Tk root + app ...
        splash.close()
    """
    def __init__(self, image_path: str | None = None, title: str = "ComputerVisionCounter",
                 min_show_ms: int = 900, bg: str = "#0e2a2d", fg: str = "#e7d4ac",
                 max_w: int = 520, max_h: int = 360, border_radius_px: int = 12):
        self.min_show_ms = int(min_show_ms)
        self.bg, self.fg = bg, fg
        self.max_w, self.max_h = int(max_w), int(max_h)
        self.border_radius_px = int(border_radius_px)
        self.title = title
        self.image_path = Path(image_path) if image_path else _find_logo()
        self._tk = None
        self._start = None
        self._photo = None  # keep ref

    def _center_geometry(self, w: int, h: int) -> str:
        sw = self._tk.winfo_screenwidth()
        sh = self._tk.winfo_screenheight()
        x = int((sw - w) / 2)
        y = int((sh - h) / 2.8)
        return f"{w}x{h}+{x}+{y}"

    def show(self):
        self._tk = tk.Tk()
        self._tk.overrideredirect(True)           # no window chrome
        try: self._tk.attributes("-topmost", True)
        except Exception: pass
        self._tk.configure(background=self.bg)

        # Container with a small “card” look
        outer = tk.Frame(self._tk, bg=self.bg)
        outer.pack(fill="both", expand=True, padx=18, pady=18)

        card = tk.Frame(outer, bg=self.bg, highlightthickness=1, highlightbackground=self.fg)
        card.pack(fill="both", expand=True)

        # Image (optional)
        if self.image_path and self.image_path.exists():
            try:
                if _PIL_OK:
                    img = Image.open(self.image_path)
                    # scale to fit
                    ratio = min(self.max_w / img.width, self.max_h / img.height, 1.0)
                    if ratio < 1.0:
                        img = img.resize((int(img.width * ratio), int(img.height * ratio)), Image.LANCZOS)
                    self._photo = ImageTk.PhotoImage(img)
                else:
                    # Tk's PhotoImage doesn’t handle JPEG; this will work if it's PNG/GIF
                    self._photo = tk.PhotoImage(file=str(self.image_path))
                lbl_img = tk.Label(card, image=self._photo, bg=self.bg)
                lbl_img.pack(padx=20, pady=(20, 10))
            except Exception:
                # if image fails, we'll just show text
                pass

        # Title
        lbl = tk.Label(card, text=self.title, bg=self.bg, fg=self.fg, font=("Segoe UI", 13, "bold"))
        lbl.pack(padx=20, pady=(0, 18))

        # Size/position and draw once
        w = max(320, min(self.max_w + 56, 680))
        h = max(140, min(self.max_h + 92, 480))
        self._tk.geometry(self._center_geometry(w, h))
        self._tk.update_idletasks()
        self._tk.update()
        self._start = time.perf_counter()

    def close(self):
        if not self._tk: return
        elapsed_ms = int((time.perf_counter() - self._start) * 1000) if self._start else 0
        wait_ms = max(0, self.min_show_ms - elapsed_ms)
        if wait_ms > 0:
            time.sleep(wait_ms / 1000.0)
        try:
            self._tk.destroy()
        except Exception:
            pass
        self._tk = None
