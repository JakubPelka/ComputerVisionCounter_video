# cv_video.py — cienki starter aplikacji + GUI glue
import os, json, zipfile, threading, time, math, sys
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

# GUI
from cv_video_gui import ScrollableFrame, CounterEditor, AppUIMixin

# CV
import cv2
import numpy as np
import pandas as pd
import torch
from PIL import Image, ImageTk

# Run & overlay (NOWE MODUŁY)
from cv_video_run import run as core_run

# ===================== PRESETY / STAŁE =====================
SUPPORTED_VID_EXTS = (".mp4", ".mov", ".avi", ".mkv", ".m4v", ".wmv", ".mpg", ".mpeg", ".ts")
MODEL_DIRNAME = "models"

VIDEO_PRESETS = {
    1: {"imgsz": 640,  "conf": 0.50, "iou": 0.60, "frame_skip": 2, "track_buffer": 30, "match_thresh": 0.80, "min_hits": 2},
    2: {"imgsz": 896,  "conf": 0.55, "iou": 0.55, "frame_skip": 2, "track_buffer": 45, "match_thresh": 0.80, "min_hits": 2},
    3: {"imgsz": 960,  "conf": 0.60, "iou": 0.50, "frame_skip": 1, "track_buffer": 60, "match_thresh": 0.78, "min_hits": 2},
    4: {"imgsz": 1280, "conf": 0.65, "iou": 0.50, "frame_skip": 1, "track_buffer": 75, "match_thresh": 0.75, "min_hits": 3},
    5: {"imgsz": 1280, "conf": 0.70, "iou": 0.45, "frame_skip": 0, "track_buffer": 90, "match_thresh": 0.75, "min_hits": 3},
}
DEFAULT_QUALITY = 5
DEFAULT_TRACKER = "bytetrack"

LINE_MIN_GAP_FRAMES_DEFAULT = 8
LINE_MIN_SEP_PX_DEFAULT    = 12
ZONE_MIN_GAP_FRAMES_DEFAULT = 6

# ===================== UTIL (proste, zostają tutaj) =====================
def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True); return p

def device_auto_str() -> str:
    return "0" if torch.cuda.is_available() else "cpu"

def score_weight_name(p: Path) -> int:
    name = p.name.lower(); score = 0
    try: score += int(p.stat().st_size // (1024*1024))
    except Exception: pass
    if "x.pt" in name: score += 100
    if "l.pt" in name: score += 80
    if "m.pt" in name: score += 60
    return score

def find_best_weights(models_dir: Path) -> Path | None:
    cands = list(models_dir.glob("*.pt")) + list(models_dir.glob("*.zip"))
    if not cands: return None
    cands.sort(key=score_weight_name, reverse=True); return cands[0]

def resolve_weights_to_pt(path: Path, extract_dir: Path) -> Path:
    if path.suffix.lower() == ".pt": return path
    if path.suffix.lower() == ".zip":
        ensure_dir(extract_dir)
        with zipfile.ZipFile(path, "r") as z: z.extractall(extract_dir)
        pts = list(extract_dir.rglob("*.pt"))
        if not pts: raise RuntimeError("W archiwum .zip nie znaleziono pliku .pt")
        pts.sort(key=score_weight_name, reverse=True); return pts[0]
    raise ValueError("Wybierz .pt lub .zip")

def numbered_path(path: Path) -> Path:
    if not path.exists(): return path
    stem, suf = path.stem, path.suffix; i = 1
    while True:
        cand = path.with_name(f"{stem}_{i}{suf}")
        if not cand.exists(): return cand
        i += 1

def open_video_writer_collision(path: Path, w: int, h: int, fps: float) -> (cv2.VideoWriter, Path):
    out_path = path
    try:
        if out_path.exists():
            try: out_path.unlink()
            except Exception: pass
        writer = cv2.VideoWriter(str(out_path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
        if writer.isOpened(): return writer, out_path
    except Exception:
        pass
    out_path = numbered_path(path)
    writer = cv2.VideoWriter(str(out_path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    return writer, out_path

def save_json_collision(obj, path: Path) -> Path:
    try:
        if path.exists():
            try: path.unlink()
            except Exception: pass
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
        return path
    except Exception:
        alt = numbered_path(path)
        with open(alt, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
        return alt

def save_csv_collision(df: pd.DataFrame, path: Path) -> Path:
    try:
        if path.exists():
            try: path.unlink()
            except Exception: pass
        df.to_csv(path, index=False, encoding="utf-8")
        return path
    except Exception:
        alt = numbered_path(path)
        df.to_csv(alt, index=False, encoding="utf-8")
        return alt

# ===================== YOLO CHECK =====================
try:
    from ultralytics.nn.modules import block as _ublock
    if not hasattr(_ublock, "C3k2"):
        raise RuntimeError("Ultralytics bez wsparcia YOLOv11 (brak C3k2).")
except Exception as e:
    print("Ultralytics check:", e, file=sys.stderr)

from ultralytics import YOLO
try:
    import supervision as sv
except Exception:
    sv = None

# ===================== APP =====================
class App(AppUIMixin, tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Unidrone VIDEO – liczenie przekroczeń linii/stref (YOLO + ByteTrack)")
        self.geometry("1100x860")

        self.input_dir = tk.StringVar()
        self.output_dir = tk.StringVar()
        models_default = Path(__file__).parent / MODEL_DIRNAME
        self.weights_path = tk.StringVar(value=str(find_best_weights(models_default) or models_default))

        self.quality = tk.IntVar(value=DEFAULT_QUALITY)
        self.tracker_kind = tk.StringVar(value=DEFAULT_TRACKER)
        self.overlay_mode = tk.StringVar(value="centroid")  # "centroid"|"boxes"|"boxes_conf"

        self.model = None; self.names = None; self.class_vars = []
        self.selected_files = []

        self.advanced_override = False
        self.adv_params = {
            "imgsz": VIDEO_PRESETS[DEFAULT_QUALITY]["imgsz"],
            "conf": VIDEO_PRESETS[DEFAULT_QUALITY]["conf"],
            "iou": VIDEO_PRESETS[DEFAULT_QUALITY]["iou"],
            "frame_skip": VIDEO_PRESETS[DEFAULT_QUALITY]["frame_skip"],
            "track_buffer": VIDEO_PRESETS[DEFAULT_QUALITY]["track_buffer"],
            "match_thresh": VIDEO_PRESETS[DEFAULT_QUALITY]["match_thresh"],
            "min_hits": VIDEO_PRESETS[DEFAULT_QUALITY]["min_hits"],
            "line_min_gap": LINE_MIN_GAP_FRAMES_DEFAULT,
            "line_min_sep": LINE_MIN_SEP_PX_DEFAULT,
            "zone_min_gap": ZONE_MIN_GAP_FRAMES_DEFAULT,
        }

        self.progress_var = tk.DoubleVar(value=0.0)
        self.progress_label = tk.StringVar(value="Gotowe.")
        self.abort_event = threading.Event()
        self.worker_done = threading.Event()
        self.worker_thread = None

        self.build_ui()  # z mixina
        self._autoload_best_model()

    # --- drobne helpery GUI (mixin z nich korzysta) ---
    def _row_browse(self, parent, label, var, cmd, is_dir=True):
        f = tk.Frame(parent); f.pack(fill="x", pady=3)
        tk.Label(f, text=label, width=26, anchor="w").pack(side="left")
        tk.Entry(f, textvariable=var).pack(side="left", fill="x", expand=True, padx=6)
        tk.Button(f, text="Wybierz…", command=cmd).pack(side="left")

    def _update_preset_label(self):
        p = VIDEO_PRESETS.get(int(self.quality.get()), VIDEO_PRESETS[DEFAULT_QUALITY])
        self.preset_label.config(text=f"imgsz={p['imgsz']}  conf={p['conf']}  iou={p['iou']}  skip={p['frame_skip']}  buf={p['track_buffer']}  match={p['match_thresh']}  hits={p['min_hits']}")

    def browse_input(self):
        d = filedialog.askdirectory(title="Wybierz folder z wideo")
        if d: self.input_dir.set(d)

    def browse_files(self):
        files = filedialog.askopenfilenames(title="Wybierz pliki wideo",
                                            filetypes=[("Wideo","*.mp4 *.mov *.avi *.mkv *.m4v *.wmv *.mpg *.mpeg *.ts")])
        if files:
            self.selected_files = list(files); self.files_label.config(text=f"Wybrano {len(self.selected_files)} plików")
        else:
            self.selected_files = []; self.files_label.config(text="— brak —")

    def clear_files(self):
        self.selected_files = []; self.files_label.config(text="— brak —")

    def browse_output(self):
        d = filedialog.askdirectory(title="Wybierz folder wynikowy")
        if d: self.output_dir.set(d)

    def browse_weights(self):
        initdir = str(Path(self.weights_path.get()).parent) if self.weights_path.get() else str(Path(__file__).parent / MODEL_DIRNAME)
        f = filedialog.askopenfilename(initialdir=initdir, title="Wybierz wagi",
                                       filetypes=[("Wagi",".pt .zip"), ("Wszystkie","*.*")])
        if f:
            self.weights_path.set(f); self.load_model_and_classes()

    def _autoload_best_model(self):
        try:
            wp = self.weights_path.get().strip()
            if not wp or Path(wp).is_dir():
                best = find_best_weights(Path(wp) if wp else (Path(__file__).parent / MODEL_DIRNAME))
                if best: self.weights_path.set(str(best))
            if self.weights_path.get(): self.load_model_and_classes()
        except Exception: pass

    def load_model_and_classes(self):
        try:
            out_base = Path(self.output_dir.get().strip()) if self.output_dir.get().strip() else None
            out_dir = ensure_dir((out_base or Path.cwd()) / "results")
            temp_root = ensure_dir(out_dir / "temp"); extract_dir = ensure_dir(temp_root / "extracted_models")

            wp = Path(self.weights_path.get().strip())
            if wp.is_dir():
                best = find_best_weights(wp)
                if not best: raise FileNotFoundError(f"W {wp} brak .pt/.zip")
                wp = best

            pt = resolve_weights_to_pt(wp, extract_dir)
            self._log(f"Wczytuję model: {pt}")
            self.model = YOLO(str(pt)); self.names = self.model.names
            self._populate_classes(self.names); self._log("Wagi i lista klas wczytane.")
        except Exception as e:
            messagebox.showerror("Model", f"Nie można wczytać wag:\n{e}")

    def _populate_classes(self, names):
        container = self.classes_scroll.inner
        for w in container.winfo_children(): w.destroy()
        self.class_vars.clear()
        id2name = list(names.values()) if isinstance(names, dict) else list(names)
        cols = 5
        for i, nm in enumerate(id2name):
            var = tk.BooleanVar(value=False)
            cb = tk.Checkbutton(container, text=nm, variable=var)
            r, c = divmod(i, cols)
            cb.grid(row=r, column=c, sticky="w", padx=6, pady=4)
            self.class_vars.append((nm, var, i))

    def selected_class_indices(self):
        return [idx for (nm, v, idx) in self.class_vars if v.get()]

    def open_advanced(self):
        win = tk.Toplevel(self); win.title("Opcje zaawansowane"); win.geometry("560x540")
        p = VIDEO_PRESETS.get(int(self.quality.get()), VIDEO_PRESETS[DEFAULT_QUALITY])
        def add_row(lbl, var):
            f = tk.Frame(win); f.pack(fill="x", pady=3)
            tk.Label(f, text=lbl, width=26, anchor="w").pack(side="left")
            e = tk.Entry(f, textvariable=var, width=18); e.pack(side="left"); return e
        base = self.adv_params if self.advanced_override else {**p,
            "line_min_gap": LINE_MIN_GAP_FRAMES_DEFAULT,
            "line_min_sep": LINE_MIN_SEP_PX_DEFAULT,
            "zone_min_gap": ZONE_MIN_GAP_FRAMES_DEFAULT
        }
        vs = { k: tk.StringVar(value=str(base.get(k,""))) for k in
               ["imgsz","conf","iou","frame_skip","track_buffer","match_thresh","min_hits","line_min_gap","line_min_sep","zone_min_gap"] }
        for k in ["imgsz","conf","iou","frame_skip","track_buffer","match_thresh","min_hits","line_min_gap","line_min_sep","zone_min_gap"]:
            add_row(k, vs[k])
        def apply():
            try:
                cur = VIDEO_PRESETS.get(int(self.quality.get()), VIDEO_PRESETS[DEFAULT_QUALITY])
                def get_or(v, cast, key, default):
                    s = v.get().strip()
                    if s != "": return cast(s)
                    return default if key not in cur else cur[key]
                self.adv_params = {
                    "imgsz": get_or(vs["imgsz"], int, "imgsz", 960),
                    "conf": get_or(vs["conf"], float, "conf", 0.6),
                    "iou": get_or(vs["iou"], float, "iou", 0.5),
                    "frame_skip": get_or(vs["frame_skip"], int, "frame_skip", 1),
                    "track_buffer": get_or(vs["track_buffer"], int, "track_buffer", 60),
                    "match_thresh": get_or(vs["match_thresh"], float, "match_thresh", 0.78),
                    "min_hits": get_or(vs["min_hits"], int, "min_hits", 2),
                    "line_min_gap": int(vs["line_min_gap"].get() or LINE_MIN_GAP_FRAMES_DEFAULT),
                    "line_min_sep": int(vs["line_min_sep"].get() or LINE_MIN_SEP_PX_DEFAULT),
                    "zone_min_gap": int(vs["zone_min_gap"].get() or ZONE_MIN_GAP_FRAMES_DEFAULT),
                }
                self.advanced_override = True
                self._log("[ADV] Zastosowano override.")
                win.destroy()
            except Exception as e:
                messagebox.showerror("Adv", str(e))
        def reset():
            self.advanced_override = False
            self._log("[ADV] Przywrócono preset z suwaka.")
            win.destroy()
        tk.Button(win, text="Zastosuj", command=apply).pack(side="left", padx=8, pady=8)
        tk.Button(win, text="Przywróć preset", command=reset).pack(side="left", padx=8, pady=8)

    # --- sterowanie run ---
    def abort(self):
        self.abort_event.set()
        self._set_progress(None, "Przerywam…")
        def _wait_and_reset():
            try:
                if self.worker_thread is not None:
                    self.worker_done.wait(timeout=3.0)
            finally:
                self.after(0, lambda: (
                    self.progress_var.set(0.0),
                    self.progress_label.set("Przerwano. Gotowe."),
                    self.btn_start.config(state="normal"),
                    self.btn_abort.config(state="disabled")
                ))
        threading.Thread(target=_wait_and_reset, daemon=True).start()

    def start(self):
        try:
            if self.btn_start['state'] == "disabled": return
            self.abort_event.clear()
            self.btn_start.config(state="disabled")
            self.btn_abort.config(state="normal")
            self._set_progress(0.0, "Przygotowuję…")

            # Źródła: pliki / kamera / URL
            sources = []
            base_in = None
            if hasattr(self, "src_mode") and self.src_mode.get() == "camera":
                try:
                    cam_idx = int(self.cam_index.get().strip())
                except Exception:
                    messagebox.showerror("Kamera", "Index kamery musi być liczbą całkowitą.")
                    self.btn_start.config(state="normal"); self.btn_abort.config(state="disabled"); return
                sources = [cam_idx]
            elif hasattr(self, "src_mode") and self.src_mode.get() == "url":
                url = self.url_input.get().strip()
                if not url:
                    messagebox.showerror("URL", "Podaj RTSP/HTTP URL strumienia.")
                    self.btn_start.config(state="normal"); self.btn_abort.config(state="disabled"); return
                sources = [url]
            else:
                if self.selected_files:
                    sources = [Path(p) for p in self.selected_files]
                    base_in = sources[0].parent if sources and isinstance(sources[0], Path) else None
                else:
                    inp = Path(self.input_dir.get().strip())
                    if not inp.exists():
                        messagebox.showerror("Wejście", "Wskaż poprawny folder lub pliki.")
                        self.btn_start.config(state="normal"); self.btn_abort.config(state="disabled"); return
                    sources = sorted([p for p in inp.iterdir() if p.suffix.lower() in SUPPORTED_VID_EXTS])
                    if not sources:
                        self._log("Brak plików wideo w folderze.")
                        self.btn_start.config(state="normal"); self.btn_abort.config(state="disabled"); return
                    base_in = inp

            if self.model is None:
                self.load_model_and_classes()
                if self.model is None:
                    self.btn_start.config(state="normal"); self.btn_abort.config(state="disabled"); return

            selected_idx = self.selected_class_indices()
            if not selected_idx:
                messagebox.showwarning("Klasy", "Zaznacz co najmniej jedną klasę.")
                self.btn_start.config(state="normal"); self.btn_abort.config(state="disabled"); return

            out_base = Path(self.output_dir.get().strip()) if self.output_dir.get().strip() else (base_in or Path.cwd())
            outp = ensure_dir(out_base / "results")

            self.worker_done.clear()
            self.worker_thread = threading.Thread(target=core_run, args=(self, sources, outp, selected_idx), daemon=True)
            self.worker_thread.start()
        except Exception as e:
            self.btn_start.config(state="normal"); self.btn_abort.config(state="disabled")
            messagebox.showerror("Błąd", str(e))

    # --- log / progress ---
    def _log(self, msg):
        try: self.log.insert("end", msg+"\n"); self.log.see("end")
        except Exception: pass

    def _set_progress(self, percent: float|None, text: str):
        def _upd():
            # przełączanie determinate/indeterminate
            try:
                if percent is None:
                    if not getattr(self, "_progress_indeterminate", False):
                        self.progressbar.config(mode="indeterminate")
                        self.progressbar.start(10)
                        self._progress_indeterminate = True
                else:
                    if getattr(self, "_progress_indeterminate", False):
                        self.progressbar.stop()
                        self.progressbar.config(mode="determinate")
                        self._progress_indeterminate = False
                    self.progress_var.set(max(0.0, min(100.0, percent)))
            except Exception:
                pass
            self.progress_label.set(text)
        try: self.after(0, _upd)
        except Exception: pass

    def _eta(self, elapsed_s: float, progress_frac: float) -> str:
        if progress_frac <= 1e-6: return "--:--"
        total = elapsed_s / progress_frac
        remain = max(0.0, total - elapsed_s)
        m = int(remain // 60); s = int(remain % 60)
        return f"{m:02d}:{s:02d}"

# ===================== MAIN =====================
if __name__ == "__main__":
    app = App(); app.mainloop()
