@echo off
set PYTHONUTF8=1
python "%~dp0src\start.py"
